# Atlassian/Jira Quickstart — Part 04 Section 4

Status: public project facts reported by the learner on **2026-10-02**: site `https://vipravlipare.atlassian.net`, space key `MER`, Free plan. Personal verification and authentication details are withheld. No account was created or modified by the mentor.

Current handoff: do not repeat account setup merely to create evidence. Scrum and no paid extras are learner-confirmed. Historical team-managed type and invitations remain separate project checks. Keep personal verification, authentication and recovery results private; record only non-sensitive project evidence in [Day 2 evidence](part-17-day-02-evidence.md).

Project handoff: after account setup, continue with [Section 8 completion](part-04-section-08-completion.md). S8-01 is verified; S8-02 through S8-05 require your Compose file and runtime evidence. Section 9 tools remain deferred until their scheduled gates; do not install Ollama, MongoDB, Java, kind, n8n, Chroma/Qdrant, Playwright, or k6 now.

## 1. Create account

📚 Learn first: [Create an Atlassian account](https://support.atlassian.com/atlassian-account/docs/create-an-atlassian-account), read sign-up and email verification; stop before organization administration (~5 min).
↩ Return: Open [Jira Free signup](https://www.atlassian.com/try/cloud/signup?bundle=jirasoftware&edition=free&skipBundles=true), use an email you control, verify email, select Jira Free, skip invitations and extra products; done when Jira opens on a Free plan; time box: 15 min; if stuck: record the exact screen and stop.

Use a unique password. Do not paste passwords, recovery codes, QR codes, or tokens into notes, Git, Jira, or chat.

## 2. Enable personal MFA

📚 Learn first: [Manage two-step verification](https://support.atlassian.com/atlassian-account/docs/manage-two-step-verification-for-your-atlassian-account/), read authenticator setup and recovery storage; stop before organization-wide enforcement (~5 min).
↩ Return: Open Atlassian account security, choose **Manage two-step verification**, enroll an authenticator, save recovery material in private storage, and verify the page shows enabled; assess the result privately without publishing account-specific settings or storage details; time box: 10 min; if stuck: record a non-sensitive planning blocker without its security details.

## 3. Create minimal Jira space

📚 Learn first: [Create a Jira space](https://support.atlassian.com/jira-software-cloud/docs/create-a-new-project/), read creation steps; [Team-managed spaces](https://support.atlassian.com/jira-software-cloud/docs/get-started-with-team-managed-projects/), read Scrum basics (~5 min).
↩ Return: Create **Software development → Scrum → Team-managed** space named `Merlin`; keep it solo; done when the space opens and its key is recorded; time box: 10 min; if stuck: retain default workflow and record the missing change.

Keep the default workflow for Day 2. Later workflow polish may use Ready, In Progress, In Review, Blocked, Done and Deferred. Apply written WIP limit: two active checklist items total. Do not import the full Jira pack yet.

## 4. Record safe evidence

📚 Learn first: refresh the personal MFA recovery guidance linked in Section 2; stop before regeneration.
↩ Return: retain [the account completion record](part-04-accounts-completion.md); done when reported facts are dated and secrets excluded; time box: within Day 2 ritual; if stuck: record pending without copying secrets.


Record date, public Jira site address, Free plan and space key. Retain personal email-verification, MFA, sign-in and recovery checks privately. Never record passwords, MFA codes, QR images, recovery keys, recovery-storage details, payment details or full account identifiers in publishable evidence.

## 5. Completion test

📚 Learn first: refresh the personal MFA login guidance linked in Section 2; stop before security changes.
↩ Return: reuse checks already reported below rather than repeat signup; done when remaining space-type/invitation facts are recorded or pending; time box: remaining account/ritual time; if stuck: preserve current settings.

Reported public project setup October 2: Free-plan Scrum space MER and no paid extras. Personal verification, authentication, sign-in and recovery evidence is withheld; retain it privately outside Git/Jira/shared planning.


- Sign out and sign back in using MFA.
- Open Merlin space.
- Confirm plan still says Free.
- Confirm no invited users or paid products.
- Record any blocker and next action.

## Sources

Official pages checked 2026-10-01. Account eligibility, UI labels, and plan availability require learner verification.
