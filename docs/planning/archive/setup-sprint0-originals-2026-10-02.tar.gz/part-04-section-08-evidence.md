# Part 04 — Section 8 evidence, October 2, 2026

Status: **S8-01–S8-05 operational gates PASS on 2026-10-02**. Final evidence is [Day 3 completion record](part-17-day-03-evidence.md). The tables below are the earlier pre-correction audit, retained for traceability; their pending/blocked rows are superseded by that record. Latest user instruction authorizes assistant setup-only configuration changes. Learner mastery/elapsed time is not claimed.

## Observed results

| Gate | Observation on 2026-10-02 | Result |
|---|---|---|
| Engine and Compose | Client/server 29.7.2; Compose v5.4.0 | Observed |
| Quiet validation | `docker compose config --quiet` returned no error | Syntax passes; acceptance blocked |
| Services | `db` and `cache`, both healthy at inspection; approximately 28 hours uptime | Healthy current stack; required names differ |
| Ports | PostgreSQL `127.0.0.1:5432`; Redis `127.0.0.1:6379` | Loopback publication passes; no LAN test performed |
| PostgreSQL readiness | `pg_isready -U merlin_user -d merlin_db`: accepting connections | Readiness only; no password proof |
| Redis smoke | Container `redis-cli ping`: `PONG` | Container check passes; host check pending |
| Process owners | PostgreSQL UID 70; Redis UID 999 | Current long-running processes non-root |
| Limits | PostgreSQL memory 1073741824 bytes, NanoCpus 1000000000; Redis memory 536870912 bytes, NanoCpus 500000000 | PostgreSQL matches; Redis exceeds required 268435456-byte ceiling |
| PostgreSQL volume | `merlin_postgres_data` mounted at `/var/lib/postgresql/data` | Baseline recorded; retention test pending |
| Redis volume | `merlin_redis_data` mounted at `/data` | Baseline only; does not prove durability |
| Cluster identifier | `7691749973399031842` before any new recreation | Baseline only; after value pending |
| Redis policy | `save` = `3600 1 300 100 60 10000`; `appendonly` = `no`; `maxmemory` = `0`; `maxmemory-policy` = `noeviction` | Snapshots enabled and data limit absent; does not match smoke specification |
| Secret boundary | Compose contains a literal password (value omitted). `.env` is not tracked; `git check-ignore .env` did not establish an ignore rule | Blocked; untracked alone is insufficient |
| Images | Current tags `postgres:17-alpine`, `redis:7-alpine`; digest not specified in Compose | Blocked; current images differ from selected pins |
| Host clients | `command -v psql` and `command -v redis-cli` returned no path in this shell | Host authentication and PING pending prerequisite |
| Logging/start period | Bounded logging and required start period absent from reviewed file | Blocked |
| Accounts | GitHub origin configured; Atlassian/Jira/MFA/visibility not inspected | Learner confirmation pending |

Local image inspection returned `postgres@sha256:b0f9560a2de083e2cc7382e75f808c7381a32852a7ec49117deedb300e552b24` and `redis@sha256:858f009f9709ce576febc734aa78b8f6d624b82571f9ddb6bda4377c833b3499`. These identify the current Alpine images; **do not use them as the supplement's bookworm/trixie pins**. The supplement's selected target registry manifests were subsequently rechecked October 2 and match the recorded linux/amd64 digests; the old Alpine images remain running.

## Latest read-only audit — October 2 continuation

Both old services remain healthy with loopback publication and non-root processes. Quiet validation exits zero, but S8-02 configuration remains unchanged. Logging inspection reports `json-file` with empty options for both services, so rotation is not configured. Redis still has snapshots enabled, no data-memory ceiling and a 512 MiB container limit. Selected PostgreSQL/Redis linux/amd64 registry manifests were rechecked and match the completion supplement’s target digests; no image was downloaded.

| Authentication boundary | Observed result | Meaning |
|---|---|---|
| Container `127.0.0.1`, configured password | Database listing succeeds | Does not establish password verification |
| Container `127.0.0.1`, deliberately wrong password | Database listing also succeeds | Matching local trust rule; do not call this a negative-test pass |
| Service DNS `db`, configured password | Database listing succeeds | Current service-network positive test passes |
| Service DNS `db`, deliberately wrong password | Password authentication failed | Current service-network negative test passes |
| WSL host `127.0.0.1:5432` | Not run; host psql unavailable | Host-boundary acceptance pending |

The earlier in-container password-authentication claim is narrowed by these observations. All test strings/logs are sanitized; no real credential value is recorded. No container was stopped, recreated or changed, because corrected S8-02 has not passed. Storage baseline is preserved; after-recreation evidence remains pending.

## S8-02 — Learner correction and preservation gate

📚 Learn first: [Compose services](https://docs.docker.com/reference/compose-file/services/), read image, healthcheck, logging and memory fields; stop before examples. [Postgres official image](https://hub.docker.com/_/postgres), read initialization inputs and existing data behavior; stop before copying configuration. Read within the 35-minute S8-02 box, not in addition to it.
↩ Return: revise your own Compose against the complete [S8-02 table](part-04-section-08-completion.md#s8-02--author-the-minimal-compose-configuration); done when all table rows and quiet validation pass; time box: the remaining S8-02 allowance; if stuck: share the redacted attempt and first failing field.

Preserve project identity `merlin` and named volume `merlin_postgres_data` during service renaming. Renaming a volume key or project can attach a different empty volume and falsely appear to lose data. Review generated service and volume names before starting. Do not delete volumes, prune Docker or reset the database. Stop if an image change fails against existing data; record the error instead of retrying with empty storage. Moving a password into private configuration does not change the stored database credential. If the literal credential was shared beyond this local setup, learner-owned credential rotation is needed; its verification must include the existing database, without placing passwords in commands or evidence.

Selected targets remain the supplement's PostgreSQL 17.11-bookworm and Redis 8.10.2-trixie with registry-verified digests. Keep pgvector and optional tools deferred. Redis must disable snapshots and append-only persistence, set its data limit to 128 MiB, preserve no-eviction, and use the 256 MiB container ceiling. Configure bounded logs and 30-second startup/stop allowances. Do not publish credentials or full resolved Compose output.

## S8-03/S8-04/S8-05 — Remaining proof

📚 Learn first: [PostgreSQL readiness](https://www.postgresql.org/docs/17/app-pg-isready.html), read what readiness proves; [psql](https://www.postgresql.org/docs/17/app-psql.html), read password/connection options; [Compose down](https://docs.docker.com/reference/cli/docker/compose/down/), read default removal and volume option; stop after those sections. Reading stays inside the existing supplement boxes.
↩ Return: after S8-02 passes, execute the supplement's full host-client, correct-password, wrong-password and controlled recreation checks yourself; done when dated before/after volume, cluster and database results match and all secret checks pass; time boxes: S8-03 25, S8-04 20, S8-05 10 minutes including reading; if stuck: stop at the first failure and preserve storage.

| Pending case | Expected result | Actual result |
|---|---|---|
| Correct host password | Configured database listed through `127.0.0.1` | Pending |
| Wrong host password | Authentication rejected | Pending |
| Host Redis PING | `PONG` through `127.0.0.1` | Pending |
| Recreation | Same PostgreSQL volume and identifier `7691749973399031842`, same database list | Pending |
| Corrected limits/policy/logging | Match S8-02 table | Pending |
| Private environment file | Ignored, untracked, required values present, no exposed values | Pending |
| Learning | Explain-back answered, whiteboard and re-quiz recorded | Pending |
| Time | Actual learner minutes and displaced work recorded | Not supplied |

The agent's read-only checks are not learner execution time or proof of learner understanding. Existing setup runs and October 1 authentication claims remain attributed to their prior audit; no new authentication pass is claimed here. Full Section 8 cannot honestly be completed within Day 2's 15-minute review. Day 3/4 gates and equal Day 6 displacement remain required if work spills.

## Resource index

Official Compose services, Postgres image, PostgreSQL readiness/psql, Docker inspection/down and Redis persistence documentation opened successfully **2026-10-02**. Context7 unavailable. Documentation checks alone do not verify runtime corrections. The later direct registry inspection verifies the selected target manifests, while corrected runtime acceptance remains pending. [Docker inspect](https://docs.docker.com/reference/cli/docker/inspect/); [Redis persistence](https://redis.io/docs/latest/operate/oss_and_stack/management/persistence/). Exact executable steps remain in the linked completion supplement.
