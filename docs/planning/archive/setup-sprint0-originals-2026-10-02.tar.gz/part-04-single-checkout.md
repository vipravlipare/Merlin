# Part 04 — One Merlin checkout for Windows and Ubuntu

Verified documentation and local observations: **2026-10-02**. The request is interpreted as keeping Merlin project files identical when accessed from either operating system. Windows and Ubuntu remain different operating systems; package binaries and versions are not synchronized by this arrangement.

## Implemented access — October 2

A Windows desktop shortcut named **Merlin Ubuntu** now targets VS Code with `--remote wsl+Ubuntu /home/vipra/Merlin`. Its arguments were inspected, and the WSL share’s Compose file is accessible from Windows. Launch this shortcut for future work. The old C: checkout was retained without modification. These actions are explicitly authorized by the learner's request to use Ubuntu. The agent did not launch the desktop UI; file-level access and shortcut configuration were verified.

## SC-01 — Open the same files from both systems | 5 minutes

📚 Learn first: [Microsoft WSL file systems](https://learn.microsoft.com/en-us/windows/wsl/filesystems), read File storage and performance and Windows File Explorer access; stop before interoperability examples (2 minutes included). [VS Code WSL](https://code.visualstudio.com/docs/remote/wsl), read opening a folder in WSL; stop before advanced configuration (1 minute included).
↩ Return: open the Ubuntu repository through Windows Explorer and use VS Code WSL for edits; done when both views refer to the same files and no work is done in the older C: copy; time box: 5 minutes including reading, inside existing Day 3 Learn/configuration time; if stuck: start Ubuntu and browse the WSL share, without copying files.

Canonical folder: `/home/vipra/Merlin`.

Windows access to those exact files: `\\wsl$\Ubuntu\home\vipra\Merlin`.

1. Open Windows File Explorer using Windows+E.
2. Click the address bar, paste `\\wsl$\Ubuntu\home\vipra\Merlin`, then press Enter. The distribution name is Ubuntu, observed in this session.
3. Open `docs\planning\part-17-sprint0.md` through that folder. This is the current Ubuntu file, not a synchronized copy.
4. In your Ubuntu terminal, run the commands below to open the canonical folder in VS Code. Confirm the lower-left remote indicator says WSL: Ubuntu.
5. Use this folder for future work. You may pin the Explorer folder to Quick access for convenience. Do not edit the old `C:\Users\vipra\Merlin` copy or copy its files over the current checkout. Retain that old folder until any unique material has been deliberately reviewed; no deletion is required.

```bash
cd /home/vipra/Merlin
pwd
git rev-parse --show-toplevel
code .
```

Expected directory and Git top level: `/home/vipra/Merlin`. VS Code opening is a learner action, not an agent-executed GUI operation. If the share is unavailable, launch Ubuntu through the Start menu and retry; if its distribution name differs on a future installation, use the actual name shown under `\\wsl$`.

This keeps both views identical because they access the same files. No background sync, copy script or second checkout is required. Use Ubuntu Git, Python, Node, Docker commands and VS Code WSL for development. Windows Explorer is a view of the files, not a reason to run Windows package managers against this Linux environment. WSL must be available for the share to work. This is not a backup: use the project's normal Git/evidence workflow, and keep private inputs/recovery material out of Git.

## SC-02 — Verify that the views agree | 2 minutes

📚 Learn first: refresh the canonical-path check above; no extra external reading.
↩ Return: compare the existing sprint file through the WSL Explorer folder and VS Code WSL; done when both show the corrected Day 3 budget and DSA deferral; time box: 2 minutes within existing Day 3 verification time; if stuck: check the address bar before changing any file.

No test file is necessary. The canonical sprint file has Day 3 IMPLEMENT 60 minutes, VERIFY 30 minutes and UNCOMMITTED 30 minutes. The older Windows checkout contains stale planning text and lacks the current Compose/private input files. Seeing the old 75/45-minute schedule means you opened the old C: folder. Do not copy `.env` between checkouts or publish its contents to prove a path.

## Resource index

Microsoft WSL filesystem and VS Code WSL documentation opened successfully **2026-10-02**. Ubuntu distribution name and two separate repository folders inspected locally. Windows Explorer access must be confirmed by the learner; the subsequently authorized Ubuntu desktop shortcut was created and inspected; no symlinks or copy-sync jobs were created. Context7 unavailable.
