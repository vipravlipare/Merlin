# Part 17 — Day 3 operational completion evidence

**Operational setup complete**, executed ahead of the scheduled October 3 day on **2026-10-02**. Latest check: 19:28 EDT. The learner explicitly requested “do it for me”; this authorizes the assistant's setup-only Compose/ignore-rule edits, client downloads, controlled Docker transition and Ubuntu shortcut. It is a session exception to the earlier planning-only configuration rule. No feature code, application schema, application tests or CI was created. Do not claim the learner authored the final setup corrections or demonstrated mastery.

## Ubuntu workspace and Windows access

Canonical repository: `/home/vipra/Merlin`, WSL distribution `Ubuntu`, Ubuntu 26.04 LTS. Windows reads the same files at `\\wsl$\Ubuntu\home\vipra\Merlin`. The share’s Compose file was successfully found through Windows PowerShell. A **Merlin Ubuntu** desktop shortcut was created and inspected: target Windows VS Code `Code.exe`; arguments `--remote wsl+Ubuntu /home/vipra/Merlin`. The old `C:\Users\vipra\Merlin` folder remains untouched, rather than overwritten or deleted. Use the new shortcut for future work; a desktop UI launch was not performed by the agent.

## S8-01–S8-05 acceptance

| Gate | Observed result | Status |
|---|---|---|
| S8-01 engine/pins | Engine 29.7.2, Compose v5.4.0; selected linux/amd64 manifests verified and downloaded | Pass |
| S8-02 project/services | Project merlin; exactly postgres/redis | Pass |
| Images | PostgreSQL 17.11-bookworm and Redis 8.10.2-trixie, pinned to verified digests | Pass |
| Private inputs | Three required-nonempty PostgreSQL references; `.env` exists, ignored, untracked; no credential values printed | Pass |
| Health policy | Both: interval 10s, timeout 5s, retries 5, start period 30s | Pass |
| Container state | Both healthy after corrected startup | Pass |
| PostgreSQL readiness | Accepting connections | Pass |
| Container positive authentication | Service-DNS TCP connection lists merlin_db and three system/template databases | Pass |
| Container negative authentication | Deliberately wrong password rejected with password authentication failed | Pass |
| Native WSL host positive authentication | Host client connects to 127.0.0.1:5432 and lists configured database | Pass |
| Native WSL host negative authentication | Deliberately wrong password rejected | Pass |
| Redis connectivity | Host and container PING return PONG | Pass |
| Exposure | Only 127.0.0.1:5432 and 127.0.0.1:6379 published; no host networking | Pass; no LAN penetration test claimed |
| Process owners | PostgreSQL and Redis long-running processes UID 999 | Pass |
| Limits | PostgreSQL 1073741824 bytes, 1 CPU; Redis 268435456 bytes, 0.5 CPU | Pass |
| Redis data policy | save empty; appendonly no; maxmemory 134217728; maxmemory-policy noeviction | Pass; keys deliberately disposable |
| Logging | json-file, max-size 10m, max-file 3 on each service | Pass |
| Stop/restart policy | 30-second graceful stop; unless-stopped retained/documented | Pass |
| PostgreSQL storage | merlin_postgres_data at /var/lib/postgresql/data; same cluster identifier before/after recreation | Pass |
| Database listing retention | merlin_db, postgres, template0, template1 retained | Pass |
| Evidence | This sanitized record; no resolved configuration or secret contents shared | Pass |

Exact image manifest pins:

- PostgreSQL: `sha256:91eb910c44c7ed13f7f1a4ccadaa9ca72ef14cddc04cacb6e070e48eb44731a3`.
- Redis: `sha256:7ef5b5cec96495a04ca7feff88a9492efeab8053fb284d24bdd73344c9245a48`.

Storage preservation baseline and result: project `merlin`; volume `merlin_postgres_data`; cluster ID **7691749973399031842** before and after `docker compose down --remove-orphans --timeout 30` followed by corrected `docker compose up --wait --wait-timeout 120 postgres redis`. No volume-deletion option was used. The one-time orphan cleanup removed only the two old db/cache project containers. The service-name/image transition itself was the controlled recreation; no redundant second restart was needed.

The baseline database dump is private at `/tmp/merlin-setup-backup/database-before.dump` (mode 600; parent 700), with the old Compose file beside it. `/tmp` is temporary and is not a long-term backup. This proves retention of the initialized setup cluster, not application-data restore or backup mastery.

## Compatibility and local limitations

Native host tools were obtained from official configured Ubuntu repositories and extracted into ignored `.tools/ubuntu-clients`: PostgreSQL client 18.6, libpq5 18.6, Redis CLI 8.0.5, libjemalloc2 5.3.0-4 and liblzf1 3.6-4build1. The host client version differs from server 17.11; its exercised connection/listing behavior passes. No client server daemon was installed, no sudo password was requested and no system package database was changed. Original Debian package downloads are in `/tmp/merlin-client-packages`; operational client files remain in the ignored repository tools folder.

For a future Ubuntu terminal session, these two commands make the local client binaries available for the current session:

```bash
export PATH="/home/vipra/Merlin/.tools/ubuntu-clients/usr/lib/postgresql/18/bin:/home/vipra/Merlin/.tools/ubuntu-clients/usr/bin:$PATH"
export LD_LIBRARY_PATH="/home/vipra/Merlin/.tools/ubuntu-clients/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
```

The clients were tested directly against host-published ports without printing their password. They are local prerequisites, not tracked project dependencies; a clean clone will need these documented prerequisites again. Day 4 fresh-clone proof remains pending.

Redis logs warn that authentication/network protection inside the container is absent. This is the already specified trusted-local/synthetic limitation: host ports bind loopback, but local processes/shared-network containers can access it. No production security claim is made. The only PostgreSQL FATAL messages observed in the checked log window match intentional wrong-password tests. No startup or collation mismatch warning was observed. Read-only collation inspection reports previous recorded versions empty and current actual version 2.36; no index rebuild/version refresh was performed or claimed.

Snapshot: PostgreSQL about 21.21 MiB/1 GiB; Redis about 6.121 MiB/256 MiB. Writable container layers: PostgreSQL 20480 bytes, Redis 4096 bytes; named volumes total about 48.13 MB. Global Docker disk totals include unrelated containers/cache and are not Merlin’s project size. Windows C: free space about 38 GiB, above the 20 GiB pause threshold. No unrelated Docker data was pruned.

## Learning, time and completion boundary

Health means accepting requests; authentication proves correct credentials work and incorrect ones are rejected; retention proves the same volume/cluster/database survives recreation. These explanations and checks are mentor-provided evidence, not proof the learner can reproduce/explain them unaided. Learner re-quiz, whiteboard and actual minutes remain unreported. DSA is deferred at the learner's explicit request and is not a transition blocker. Atlassian account gates are learner-confirmed; GitHub web MFA/visibility and team-managed type remain separate unverified account facts.

Day 3 budget remains 180 minutes: Learn 30, Implement 60, Verify 30, Storage 15, uncommitted former DSA 30, Ritual 15. Agent execution is not learner elapsed time. No invented stand-up time, learning answers or claim of completed 37-day features is made. Operational environment work through Day 3 is complete; Day 4 documentation/doctor/CI/fresh-clone and later S1 feature work have not been executed.

## Recovery path and resources

📚 Learn first: [Section 8 completion guide](part-04-section-08-completion.md), read stopping/storage semantics and secret-redaction rules; stop before executing any teardown. [Single-checkout guide](part-04-single-checkout.md), read Ubuntu/Windows access; stop before repeating verified checks.
↩ Return: use the existing corrected stack from Ubuntu; done when the next scheduled setup/documentation gate is selected without overwriting private inputs; time box: the next day's existing block; if stuck: retain volumes and report the first sanitized error.

Rollback is available if a later concrete regression warrants it: stop only this project's services while retaining volumes, restore the saved old Compose fields, and use its original db/cache service names with project merlin and the existing private `.env`. The old configuration was saved outside the repository; use an explicit `--env-file /home/vipra/Merlin/.env` if invoking it from `/tmp`. Never restore by deleting the database volume. Do not perform rollback or restore an old dump over new data without reviewing what would be lost.

Migration skill used: `.agents/skills/migration/SKILL.md`; forward transition and retained rollback artifacts preserve the original cluster. Official Docker/WSL/Redis/PostgreSQL links and target registry metadata were checked October 2, 2026. Context7 unavailable.
