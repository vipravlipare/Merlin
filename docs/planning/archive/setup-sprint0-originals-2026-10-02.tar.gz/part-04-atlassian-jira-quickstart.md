# Atlassian/Jira Quickstart — Part 04 Section 4

Status: core account facts confirmed by learner on **2026-10-02**: site `https://vipravlipare.atlassian.net`, space key `MER`, email verified, personal MFA enabled, Free plan. No account was created or modified by the mentor.

Current handoff: do not repeat signup/MFA enrollment. Recovery storage, successful MFA sign-in, Scrum and no paid extras are now learner-confirmed. Only team-managed type and invitations remain separately unconfirmed. Record these in [Day 2 evidence](part-17-day-02-evidence.md). Never share recovery material.

Project handoff: after account setup, continue with [Section 8 completion](part-04-section-08-completion.md). S8-01 is verified; S8-02 through S8-05 require your Compose file and runtime evidence. Section 9 tools remain deferred until their scheduled gates; do not install Ollama, MongoDB, Java, kind, n8n, Chroma/Qdrant, Playwright, or k6 now.

## 1. Create account

📚 Learn first: [Create an Atlassian account](https://support.atlassian.com/atlassian-account/docs/create-an-atlassian-account), read sign-up and email verification; stop before organization administration (~5 min).
↩ Return: Open [Jira Free signup](https://www.atlassian.com/try/cloud/signup?bundle=jirasoftware&edition=free&skipBundles=true), use an email you control, verify email, select Jira Free, skip invitations and extra products; done when Jira opens on a Free plan; time box: 15 min; if stuck: record the exact screen and stop.

Use a unique password. Do not paste passwords, recovery codes, QR codes, or tokens into notes, Git, Jira, or chat.

## 2. Enable personal MFA

📚 Learn first: [Manage two-step verification](https://support.atlassian.com/atlassian-account/docs/manage-two-step-verification-for-your-atlassian-account/), read authenticator setup and recovery storage; stop before organization-wide enforcement (~5 min).
↩ Return: Open Atlassian account security, choose **Manage two-step verification**, enroll an authenticator, save recovery material in private storage, and verify the page shows enabled; done when personal MFA is enabled; time box: 10 min; if stuck: record the available method without recording its secret.

## 3. Create minimal Jira space

📚 Learn first: [Create a Jira space](https://support.atlassian.com/jira-software-cloud/docs/create-a-new-project/), read creation steps; [Team-managed spaces](https://support.atlassian.com/jira-software-cloud/docs/get-started-with-team-managed-projects/), read Scrum basics (~5 min).
↩ Return: Create **Software development → Scrum → Team-managed** space named `Merlin`; keep it solo; done when the space opens and its key is recorded; time box: 10 min; if stuck: retain default workflow and record the missing change.

Keep the default workflow for Day 2. Later workflow polish may use Ready, In Progress, In Review, Blocked, Done and Deferred. Apply written WIP limit: two active checklist items total. Do not import the full Jira pack yet.

## 4. Record safe evidence

📚 Learn first: refresh the personal MFA recovery guidance linked in Section 2; stop before regeneration.
↩ Return: retain [the account completion record](part-04-accounts-completion.md); done when reported facts are dated and secrets excluded; time box: within Day 2 ritual; if stuck: record pending without copying secrets.


Record date, Atlassian email verified, Jira site address, Free plan, space key, MFA enabled, and recovery material stored privately. Never record passwords, MFA codes, QR images, recovery keys, payment details, or full account identifiers.

## 5. Completion test

📚 Learn first: refresh the personal MFA login guidance linked in Section 2; stop before security changes.
↩ Return: reuse checks already reported below rather than repeat signup; done when remaining space-type/invitation facts are recorded or pending; time box: remaining account/ritual time; if stuck: preserve current settings.

Reported complete October 2: email verified, Free plan, MFA enabled, MFA sign-in works, recovery stored in notes, Scrum space MER and no paid extras. Keep recovery notes private, outside Git/Jira/shared planning.


- Sign out and sign back in using MFA.
- Open Merlin space.
- Confirm plan still says Free.
- Confirm no invited users or paid products.
- Record any blocker and next action.

## Sources

Official pages checked 2026-10-01. Account eligibility, UI labels, and plan availability require learner verification.
