# Part 04 — S8-02 guided Compose worksheet

Prepared **2026-10-02** from your existing Compose attempt. Superseded execution status: S8-02 is now complete following the learner’s explicit request for assistant setup changes; see [final evidence](part-17-day-03-evidence.md). Remaining instructions are reproduction/learning reference, not outstanding edits. This is an editing specification, not a generated configuration. You make the edits in VS Code connected to WSL, at `/home/vipra/Merlin`. No application feature, configuration change or runtime completion is claimed by this worksheet.

## W1 — Protect the existing database and private inputs | 10 minutes

📚 Learn first: [Compose interpolation](https://docs.docker.com/reference/compose-file/interpolation/), read required nonempty values and literal-dollar escaping; stop before merge behavior (3 minutes included).
↩ Return: edit your own private inputs and ignore rule before moving credentials out of Compose; done when the private file is ignored/untracked and required values cannot silently become empty; time box: 10 minutes including reading; if stuck: ask about one interpolation field, without sharing secret values.

Open your existing `docker-compose.yml`. Preserve top-level volume keys `postgres_data` and `redis_data`, PostgreSQL mount `/var/lib/postgresql/data`, and project identity `merlin`. Preserve current PostgreSQL username/database and stored credential for this existing cluster. A changed environment password does not rotate an initialized database password. Do not delete the volume or reset the database.

Create your own private `.env` in the repository root. It needs three names: `POSTGRES_USER`, `POSTGRES_DB`, `POSTGRES_PASSWORD`. Copy the current values privately; this is relocation, not credential rotation. Do not paste the values into chat or planning documents. Author a `.gitignore` rule for this file before staging. Do not create a second real credential file as an example. The local file is not encrypted secret storage.

In Compose's existing PostgreSQL environment mapping, replace literal values with required-nonempty references to those same names. The documentation's `${VAR:?error}` form rejects unset or empty inputs. Write your own descriptive error text. Compose reads the root `.env` for interpolation; it still needs the environment mapping to pass those values to the container. Avoid a redundant whole-file `env_file` entry that would also expose every variable to Redis.

No Redis password is added: this is trusted-local, synthetic, unauthenticated smoke use only. A `REDIS_PASSWORD` variable alone does not configure authentication. No sensitive data belongs in Redis.

## Requested small hint — connect PostgreSQL inputs

The learner explicitly asked to continue replacing literal PostgreSQL values. This is a four-line hint for the existing environment block, not a finished Compose file. Type it yourself at the same indentation as your current block; do not paste it into `.env`.

```yaml
    environment:
      POSTGRES_USER: ${POSTGRES_USER:?Set POSTGRES_USER in .env}
      POSTGRES_DB: ${POSTGRES_DB:?Set POSTGRES_DB in .env}
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD:?Set POSTGRES_PASSWORD in .env}
```

The name to the left of each colon is the container environment name. The expression on the right gets the input Compose reads from `.env` (or an existing shell variable). `:?` stops validation when an input is missing or empty. No credential is embedded in this hint.

📚 Learn first: [Compose interpolation](https://docs.docker.com/reference/compose-file/interpolation/), refresh required values; stop after `:?` (within W1/W2 time).
↩ Return: replace only the existing PostgreSQL environment block, save, then run `docker compose config --quiet`; done when quiet validation exits zero without a literal credential in the file; time box: 5 minutes from the existing configuration block; if stuck: share only the redacted error. Do not run plain `docker compose config`, change the stored password or restart containers yet.

W1 evidence: `.env` exists, ignored and untracked, confirmed by safe Git checks. Its contents have not been printed or inspected. VS Code terminal injection can remain disabled because Compose reads `.env` independently. The three required input-reference fields are now verified in the learner file; quiet validation passes. The remaining W2 fields are still pending.

## W2 — Correct fields in the existing file | 15 minutes

📚 Learn first: [Compose services](https://docs.docker.com/reference/compose-file/services/), read image, healthcheck, memory, logging and stop_grace_period; stop before unrelated fields (5 minutes included). [Redis configuration](https://redis.io/docs/latest/operate/oss_and_stack/management/config/), read command-line configuration; stop before production tuning (2 minutes included).
↩ Return: revise the fields listed below by hand; done when every row matches your file and you can explain each value; time box: 15 minutes including reading; if stuck: keep the partially edited file and name the first unclear row.

| Existing location | Your required edit | Reason/check |
|---|---|---|
| Service key `db` | Rename to `postgres` | Commands and service DNS match the guide |
| Service key `cache` | Rename to `redis` | Commands and service DNS match the guide |
| `container_name` values | You may retain current names; do not confuse them with service keys | `docker compose exec` uses service keys |
| PostgreSQL image | Official `postgres`, exact tag `17.11-bookworm`, linux/amd64 digest `sha256:91eb910c44c7ed13f7f1a4ccadaa9ca72ef14cddc04cacb6e070e48eb44731a3` | Image reference uses repository, tag and `@sha256` digest; registry checked October 2 |
| Redis image | Official `redis`, exact tag `8.10.2-trixie`, linux/amd64 digest `sha256:7ef5b5cec96495a04ca7feff88a9492efeab8053fb284d24bdd73344c9245a48` | Same immutable-pin rule |
| Published ports | Keep existing `127.0.0.1` bindings | Do not broaden exposure |
| PostgreSQL health command | Keep `pg_isready`, using configured user/database | If the container shell expands a variable, use Compose literal-dollar escaping `$$` |
| Redis health command | PING must return PONG | Existing shell assertion can remain; explain its exit status |
| Both healthcheck timing groups | interval 10s; timeout 5s; retries 5; add start_period 30s | Initialization gets a grace period |
| PostgreSQL resource limits | Keep 1 CPU and 1 GiB maximum | Current runtime matches target |
| Redis resource limits | Keep 0.5 CPU; reduce memory to 256 MiB | Current 512 MiB does not match target |
| Redis startup `command` arguments | Explicitly disable snapshots with an empty `save` argument, disable appendonly, set maxmemory 128mb, set maxmemory-policy noeviction | Use an argument list if helpful; an empty argument must stay empty, not disappear |
| Redis named storage | Keep `redis_data` mounted at `/data` | Volume does not make deliberately disposable keys durable |
| Each service's logging | Driver json-file; options max-size 10m and max-file 3; option values are strings | Three bounded files per service |
| Each service's stop policy | stop_grace_period 30s | Allows graceful shutdown |
| Existing restart policy | Keep only if you document why unless-stopped is wanted locally | It can restart the stack when the engine restarts |
| Network | Keep one project bridge; no host network, privileged mode, Docker socket, external dependency or cross-service depends_on | These two services do not depend on each other |

You may retain the current deploy/resource block if its limits are enforced by this Compose installation, as observed. Do not add a second conflicting limit block. If switching to service-level `cpus`/`mem_limit`, remove conflicting duplicates and verify runtime limits afterward.

**Service rename warning:** existing containers still belong to old service keys. Keeping their fixed container names can cause a name or port conflict on the first new startup. Do not start the renamed services yet. W4 describes the reviewed transition; volume keys and project identity must stay unchanged.

## W3 — Quiet validation and safe review | 10 minutes

📚 Learn first: [S8-02 validation](part-04-section-08-completion.md#s8-02--author-the-minimal-compose-configuration), read expected results; stop before S8-03 (1 minute included).
↩ Return: run these checks in WSL after your edits; done when validation passes, the intended service/image references appear, and the private file is ignored/untracked; time box: 10 minutes including reading; if stuck: report the shortest redacted error and leave containers/storage alone.

```bash
cd /home/vipra/Merlin
docker compose config --quiet
printf 'validation exit=%s\n' "$?"
docker compose config --services
docker compose config --images
git check-ignore .env
git ls-files --error-unmatch .env
git diff --cached --stat
```

Run the exit-status line immediately after validation. Expected: exit 0; only postgres/redis; both selected digest pins; ignore check prints `.env`; tracked-file check fails because the file is not tracked. An untracked file without an ignore rule is insufficient. Inspect your unstaged configuration locally, but do not share resolved Compose output, `.env`, or an unredacted old diff containing the previous password. Do not stage all files blindly.

Then reply **“S8-02 attempt ready”**. The mentor can read your WSL file directly, review fields without quoting secrets, and run safe validation. No need to paste a full configuration or upload screenshots. Configuration acceptance remains pending until the edited file passes review.

Hint ladder: 1 — identify which layer owns the value: host, Compose, container or database. 2 — fix input handling first, then images, health, limits and logging, validating after each group. 3 — after sharing a redacted attempt or explicitly requesting a small example, ask for one key snippet of at most 15 lines; no finished configuration is generated.

## W4 — Day 3 transition after S8-02 passes | inside existing runtime block

📚 Learn first: [Compose down](https://docs.docker.com/reference/cli/docker/compose/down/), read remove-orphans and volume removal; stop before image deletion (2 minutes inside existing S8-03/S8-04 reading).
↩ Return: after reviewed configuration acceptance, verify only the two known old services belong to project merlin, preserve the recorded storage baseline, then remove this project's old service containers and start corrected services; done when healthy corrected services reuse the same PostgreSQL volume/cluster; time box: existing Day 3 runtime/storage blocks; if stuck: stop without volume deletion or pruning.

This step interrupts the local stack. Keep volume-deletion options absent. After confirming project identity and that no unrelated project containers would be removed, the learner uses `docker compose down --remove-orphans --timeout 30` for the one-time service rename, then the supplement's `docker compose up --wait --wait-timeout 120 postgres redis`. The orphan option is necessary because db/cache are no longer service keys in the new configuration. It is not a request to remove volumes. Do not run this before W3 review passes.

Before this transition, retain the known PostgreSQL baseline: volume `merlin_postgres_data`, cluster identifier `7691749973399031842`. After startup, compare it again; stop if it differs. Run the complete S8-03 host-client and correct/wrong-password checks and S8-04/S8-05 proof afterward. Changing from Alpine to Debian can change collation behavior; retain any warning and stop at an initialization/compatibility error rather than deleting data. Do not claim application-data restore proof from an empty setup cluster.

## Day 2 closure and Day 3 status

Day 1's recorded setup remains complete; do not rerun it. Day 2 accounts are learner-confirmed, mentor Compose review is performed, and AWS is deferred. Day 2 Learn explain-back, linked-list practice, learner review, stand-up and actual minutes are unreported; the mentor cannot supply your answers as proof you learned them. Use the closure reply in [Day 2 evidence](part-17-day-02-evidence.md). Your old quoted Day 2 totals 105 minutes and Day 3 totals 210, exceeding caps. Canonical totals remain Day 2 90, Day 3 180.

Day 3 preparation is started by this worksheet; learner execution is not yet recorded. W1–W3 total 35 minutes, including reading, and belong inside Day 3's existing 60-minute configuration block. W4 and runtime/storage proof use its remaining named blocks. Do not count these worksheet minutes on top of the sprint budget. If working ahead on October 2, record the real date and actual minutes separately; keep Day 2 at its cap.

## Resource index

Compose interpolation/services/down and Redis configuration opened successfully **2026-10-02**. Exact target manifests verified directly from the registry earlier October 2. Local supplement/evidence links checked. Context7 unavailable. Documentation and preparation are not implementation or learner learning evidence.
