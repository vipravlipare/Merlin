# Part 17 — Day 2 evidence, October 2, 2026

Status: **planning correction and read-only audit complete; Atlassian access/MFA/Free plan and sign-in learner-confirmed; DSA deferred by learner; learning proof and actual minutes unverified**. Day 2 budget: 90 minutes, no stretch. Follow [Part 17 Day 2](part-17-sprint0.md#day-2--fri-oct-2--accounts-and-compose-correction--15-h). Canonical work directory is `/home/vipra/Merlin`; missing navigation/supplements were restored from the Windows planning copy. Windows files were read but not edited.

## Operational closeout

Latest learner instruction authorizes assistant execution of the setup changes. The Day 2 Compose review is complete, and its deferred corrections have now passed [Day 3 operational acceptance](part-17-day-03-evidence.md). Day 2 may close operationally with DSA explicitly deferred and learning/time evidence unverified. The detailed earlier review below is retained as history, not current configuration failure. No learner elapsed minutes or mastery answers are invented.

## Account completion gate — D2-01

📚 Learn first: [Atlassian account creation](https://support.atlassian.com/atlassian-account/docs/create-an-atlassian-account), read email verification; [personal MFA](https://support.atlassian.com/atlassian-account/docs/manage-two-step-verification-for-your-atlassian-account/), read recovery storage; [Jira Free plan](https://support.atlassian.com/jira-cloud-administration/docs/explore-jira-cloud-plans/), read Free limitations; stop before paid features. Reading is included in Day 2's 15-minute Learn block.
↩ Return: perform the account quickstart in your own browser and fill only safe evidence below; done when the sign-in/MFA and Free-plan gates pass or an exact blocker is named; time box: 30-minute account setup block; if stuck: record the failing screen without secrets.

| Evidence | Result |
|---|---|
| Atlassian email verified | Yes — learner report, 2026-10-02 |
| Personal MFA enabled | Yes — learner report, 2026-10-02 |
| Recovery material privately stored | Learner reports key stored in notes; keep notes private and outside shared files |
| Sign-out/sign-in with MFA | Works — learner report, 2026-10-02 |
| Jira plan | Free — learner report, 2026-10-02 |
| Site address | https://vipravlipare.atlassian.net — normalized from learner-supplied URLs |
| Merlin team-managed Scrum space and actual key | MER and Scrum confirmed; team-managed type not separately confirmed |
| Invitations/paid products | No paid extras confirmed; invitations not separately reported |
| GitHub remote | Observed configured in WSL |
| GitHub MFA/repository visibility | Pending learner confirmation |
| AWS | Deferred; local-only path. No signup, CLI or resources created |

No connected authenticated account session is available here. Account email verification, MFA enrollment and terms remain learner actions. Do not send passwords, QR codes, recovery keys, API tokens or payment details.

## Compose review gate — D2-02

📚 Learn first: [Compose services](https://docs.docker.com/reference/compose-file/services/), refresh required fields; stop before finished examples, within today's review.
↩ Return: compare your redacted attempt against [S8-02](part-04-section-08-completion.md) and [observed evidence](part-04-section-08-evidence.md); done when each mismatch is corrected or explicitly deferred; time box: Day 2's 15-minute review; if stuck: continue authoring Day 3 without adding time.

Day 2 review performed: the learner-authored Compose file is unchanged from the previous audit, and `docker compose config --quiet` exits zero. No changes are staged in Git. The review identifies unfinished image pins, service names, literal credential, missing private-file ignore proof, health start period, Redis memory/persistence policy and logging. These edits are explicitly deferred to Day 3's existing 60-minute implementation block, matching Day 2's stop condition. Therefore the mentor review is complete, while learner review/explain-back and S8-02 configuration acceptance remain pending. Healthy old containers do not establish compliance. Configuration remains learner-authored under R3.

Both supplied URLs belong to the same Jira site. The working board link is [MER backlog](https://vipravlipare.atlassian.net/jira/software/projects/MER/boards/2/backlog); the For You URL is a personal landing page. These are learner-provided addresses, not browsed authenticated account evidence.

## Learner steering and Day 2 disposition

Latest learner instruction: mentor completes the Compose review; DSA is removed from required project work and will be self-directed at the learner's chosen time. Do not require DSA before Day 3 or pretend it was completed. Keep its 15-minute slot uncommitted rather than silently assign more setup. Day 2 ledger becomes 15 Learn + 30 accounts + 15 mentor review + 15 ritual + 15 uncommitted = 90 minutes. Actual elapsed minutes remain unreported.

Learner explain-back received: MFA protects against being hacked; GitHub and Atlassian have separate logins. Assessment: separate-account distinction is correct; refine MFA to requiring an additional factor when a password is stolen, and distinguish Git-over-SSH from browser MFA. Explanation provided, not a passed learner re-quiz.

Mentor Compose review complete at learner request: current file was reread, quiet validation exits zero, and required image/service/secret/health/Redis/logging corrections remain named and deferred to Day 3. No configuration was modified. Accounts and review are recorded; Day 2 may transition to Day 3 with learning mastery and time evidence honestly unverified.

Stand-up record: Atlassian MER access/MFA/Free plan confirmed; Compose reviewed; blocker is S8-02 configuration acceptance; next action is worksheet W1 private inputs/ignore boundary, then remaining edits and safe review. This is a mentor-recorded status, not invented learner elapsed time or reflection.

## Actual-time ledger and learning

| Block | Planned minutes | Actual learner minutes |
|---|---:|---|
| Learn | 15 | Not supplied |
| Account setup | 30 | Not supplied |
| Compose review | 15 | Not supplied |
| DSA | 15 reserved, now uncommitted | Deferred at learner request; no time or completion claimed |
| Ritual/evidence | 15 | Not supplied |
| Total | **90** | Not supplied |

Record explain-back answers, one confusion and resolution, three quiz answers, 60-second interview explanation, current blocker and next action during the existing ritual. Schedule re-quiz for October 4 or 5; do not claim mastery before proof. If blocked, stop at the daily cap and record equal Day 6 feature minutes displaced by unresolved setup.

## Finish Day 2 — learner actions only

Do not create another account or install optional tools. The latest learner instruction permits moving to Day 3 with DSA deferred; retain unfinished learning/time evidence as unverified. Keep the actual daily cap.

### D2-01 final account checks

📚 Learn first: [personal MFA](https://support.atlassian.com/atlassian-account/docs/manage-two-step-verification-for-your-atlassian-account/), refresh recovery storage and login; stop before organization enforcement. Use the existing Day 2 ritual allowance for this refresher and confirmation.
↩ Return: confirm the recovery material is stored privately, sign out and sign back in using MFA, open MER, and check space settings for team-managed Scrum; done when these checks and no invitations/paid extras are confirmed; time box: remaining account/ritual minutes only; if stuck: report the failing check and stop without sharing secrets.

Do not generate a new recovery key merely to prove storage. Record only yes/no. If you already performed a check, report it rather than repeat setup.

### D2-02 learner review

📚 Learn first: [S8-02 field table](part-04-section-08-completion.md#s8-02--author-the-minimal-compose-configuration), read the fields and secret/storage warnings; stop before S8-03.
↩ Return: review your file against the table, then confirm the named mismatches will move to Day 3; done when you explain why a syntax pass does not prove a secure configuration; time box: remaining portion of the existing 15-minute Compose review; if stuck: name the first unclear field. The agent does not edit your configuration under R3.

### D2-DSA — deferred at learner request

📚 Learn first: [Reverse Linked List](https://leetcode.com/problems/reverse-linked-list/), read statement/examples; stop before solutions (3 minutes within the 15-minute DSA block).
↩ Return: optional self-directed review when the learner chooses; no scheduled deadline or prerequisite for Day 3. No learning completion or time is claimed. The former 15-minute Day 2 slot stays uncommitted.

### D2-EOD closure reply

📚 Learn first: [Day 2 quiz and ritual](part-17-sprint0.md#d2-eod--verify-evidence-and-ritual--15-minutes), read the quiz and evidence requirements; stop before Day 3.
↩ Return: supply the report below without secrets; done when account checks, learning answers, actual minutes and next action are recorded; time box: existing 15-minute ritual shared with final account checks, not an extra block; if stuck: mark unanswered or unfinished and stop at the cap.

Use this reply template:

- Account checks: recovery stored privately yes/no; MFA sign-in passed yes/no; team-managed Scrum yes/no; no invitations/paid extras yes/no.
- Learn explain-back: What attack does MFA resist? Why does SSH not protect an Atlassian login? How do you recover access privately?
- Compose review: reviewed yes/no; why does quiet validation not prove a secure configuration? Confirm corrections deferred to Day 3.
- DSA: completed the three list drawings yes/no; why save the next node before changing a link? Time and auxiliary-space complexity?
- Quiz: Why is readiness different from authentication? Why does an initialization environment variable not change an existing database password? Which feature minutes move when setup overruns?
- Interview: explain host loopback ports, container service names and named volumes in 60 seconds; provide your short explanation.
- Learning log: one confusion and resolution; next action; actual minutes for Learn / accounts / Compose review / DSA / ritual, total no more than 90. If you exceeded the cap, report the real total rather than editing it to fit.

Day 2 may transition with explicit Day 3 deferrals and DSA removed from required scope; Section 8 cannot close until its full configuration/runtime/security/storage gates pass. Spaced re-quiz remains due October 4 or 5 within existing rituals. Do not mark learner proofs complete based on the mentor's answers or checks.

## Resource index

Account creation, personal MFA, Jira plan and Compose services official pages opened successfully **2026-10-02**. Learner account status and actual UI remain unverified. Context7 unavailable. Account creation, verified email, MFA and Free plan are learner-reported; no feature is claimed built.
