# Part 17 — D6 Sprint 0, revised execution plan

Canonical calendar remains Days 1–5, October 1–5, 2026. This revision separates completed setup from remaining work for next few days. No feature code. Run all work in VS Code `WSL: Ubuntu` at `/home/vipra/Merlin`. Windows access uses the same files through `\\wsl$\Ubuntu\home\vipra\Merlin`; see [single-checkout guide](part-04-single-checkout.md). The old C: checkout is not kept in sync.

## Status at October 1

Completed and verified: WSL2/Ubuntu, Windows hardware and GPU visibility, Git identity, Ubuntu GitHub SSH authentication, VS Code WSL connection, VS Code Server and Python extensions, uv/Python 3.12, Node 24 LTS/pnpm 12, Docker Desktop WSL integration, Docker Engine and Compose, and S8-01 image-manifest inspection.

October 2 learner update: Atlassian/Jira MER, email verification, MFA and Free plan confirmed. Recovery storage, MFA sign-in, Scrum and no paid extras also confirmed. Operational update: Section 8 passes; Ubuntu desktop shortcut/share verified. Still open: GitHub security/space-type facts, learner mastery/time evidence, later setup/hardware documentation; AWS deferred; README v0; CI skeleton; doctor checklist; fresh-clone test; review and S1 go/no-go. GitHub remote now exists in WSL; repository visibility and GitHub MFA remain learner-confirmed gates.

📚 Learn first: [Part 4 Section 8 completion](part-04-section-08-completion.md), read current audit and S8-02; stop before optional tools. [Master navigation](MASTER_NAVIGATION.md), read Immediate work queue; why: close setup gates before implementation (~10 min).
↩ Return to build: use day blocks below in WSL; done when each evidence item exists or has named blocker; time box: day cap; if stuck: stop at current gate and record spill.

## Current acceptance status — October 2 completion

Scope: Sprint 0 **Days 1–3**; there is no separate Day 0 in the calendar. Operational setup through Day 3 is complete. Latest learner request authorizes assistant setup-only configuration/client/shortcut changes; application features remain learner-owned. [Day 3 final evidence](part-17-day-03-evidence.md) is authoritative.

| Day | Operational status | Honest limitations |
|---|---|---|
| 1 | Existing verified setup baseline retained; no repeat installation | Original evidence remains attributed to its prior checks |
| 2 | Atlassian account/MFA/sign-in/Free plan/Scrum/recovery confirmed; Compose review and AWS deferral recorded | Learner actual minutes/mastery unreported; GitHub web MFA/visibility and team-managed type separately unverified |
| 3 | S8-01–S8-05 operational gates pass: pinned corrected stack, private inputs, host/container auth, PING, non-root/limits/logs and storage preservation | Assistant-authored corrections are not learner-authorship or mastery proof; DSA deferred; no application data/restore/production claim |

The Windows **Merlin Ubuntu** desktop shortcut opens this Ubuntu repository directly. Windows share access was verified; the old C: copy stays retained and inactive. No background synchronization is required because both active views access the same files.

## Day 1 — Thu Oct 1 — Setup baseline | COMPLETE

Budget: 1.5 h. Evidence: hardware/WSL output, tool versions, Docker status, VS Code WSL status, Ubuntu SSH success. Do not repeat work. Record missing evidence only.

## Day 2 — Fri Oct 2 — Accounts and Compose correction | 1.5 h

DAY 2 | Sprint S0 | Jira space: MER; D2-01/D2-02 are local checklist IDs, not issued Jira ticket keys | Points: not assigned to setup | Budget: 90 minutes floor, no stretch | Type: S | Rung: setup only | Checklist: S8-02 and account gates.

Goal: close the personal account gates and review the learner's Compose corrections. Done means dated account evidence and a reviewed configuration, or an explicit blocker. It does not mean Section 8 runtime acceptance has passed.

The previous version allocated 105 minutes. This replacement uses 15 Learn + 30 account setup + 15 Compose review + 15 uncommitted (former DSA) + 15 ritual = **90 minutes**. Net setup remains 60 minutes, matching Part 1. AWS stays deferred; full S8-02 authoring and runtime proof continue Day 3. Do not hide those minutes inside today's review.

### D2-01 — Learn and complete account gates | 45 minutes total

📚 Learn first: [Create an Atlassian account](https://support.atlassian.com/atlassian-account/docs/create-an-atlassian-account), read signup and verification; stop before organization administration (5 minutes). [Manage two-step verification](https://support.atlassian.com/atlassian-account/docs/manage-two-step-verification-for-your-atlassian-account/), read authenticator enrollment and recovery storage; stop before organization enforcement (5 minutes). [Create a Jira space](https://support.atlassian.com/jira-software-cloud/docs/create-a-new-project/), read Scrum/team-managed selection; stop before workflow customization (5 minutes).
↩ Return to build: follow [the account quickstart](part-04-atlassian-jira-quickstart.md) in your browser; done when email verification, personal MFA, Free plan, Merlin space and sign-in test are evidenced or blocked; time box: 30 minutes after the 15-minute reading block; if stuck: record the exact failing gate and do not choose a paid plan.

Answer before setup: What extra attack does MFA resist? Why does GitHub SSH not protect an Atlassian browser login? How do you recover access without publishing recovery material?

Use 10 minutes for signup/email verification, 10 for MFA and private recovery storage, and 10 for the solo team-managed Scrum space plus sign-out/sign-in and Free-plan check. Use existing accounts when available. Skip invitations, paid trials, extra products, automation and Jira imports. Record only site address, actual space key, plan, verification/MFA status and whether recovery material is stored privately. Keep default workflow today; written WIP limit remains two active items. GitHub remote already exists in WSL; do not recreate it or change repository visibility. GitHub MFA status still needs learner confirmation.

AWS decision today: **deferred, local-only release, no signup or deployment**. Account terms, card holds and eligibility remain unverified for this learner. Budget alerts are notifications, not a hard spending cap; see [AWS Budgets](https://docs.aws.amazon.com/cost-management/latest/userguide/budgets-managing-costs.html). No AWS CLI installation.

### D2-02 — Review Compose corrections | 15 minutes

📚 Learn first: [Compose services](https://docs.docker.com/reference/compose-file/services/), refresh image, healthcheck, memory and logging fields using S8-02's table; stop before examples. This refresher is inside this 15-minute review.
↩ Return to build: inspect your own Compose attempt against [S8-02](part-04-section-08-completion.md#s8-02--author-the-minimal-compose-configuration); done when every field is checked and quiet validation passes, or missing edits are named; time box: 15 minutes including refresher; if stuck: preserve your redacted attempt and resume authoring Day 3.

Review exact observed image pins; service names `postgres`/`redis`; private ignored environment inputs; 30-second health start period; PostgreSQL 1 GiB/1 CPU; Redis 256 MiB/0.5 CPU and 128 MiB data limit; explicit Redis disposable policy; bounded log rotation; loopback bindings. Preserve the current project identity and PostgreSQL volume. [October 2 evidence](part-04-section-08-evidence.md) records the current mismatches and storage baseline. Moving the password out of Compose does not rotate the password in an existing database. Do not delete its volume to fix authentication.

Run only the quiet validation and Git-secret checks in S8-02 after your edits. Do not print resolved Compose output. Recreating the stack belongs to Day 3/4 after review. Hints: 1 — distinguish host settings from container settings; 2 — compare one table row at a time; 3 — request a small hint only after sharing your redacted attempt. Stop when today's cap is reached.

### D2-DSA — Deferred by learner; 15-minute slot uncommitted

Latest learner instruction overrides scheduled DSA: the learner will study it independently when desired. It is not a Day 2 closure gate or Day 3 prerequisite. Keep the former slot uncommitted; do not claim completion or add setup minutes automatically.

📚 Learn first: [Reverse Linked List](https://leetcode.com/problems/reverse-linked-list/), read the statement and examples only; stop before solutions (3 minutes within this block).
↩ Return to build: optional self-directed list review when the learner chooses; no required Day 2 time box or deadline. No cache feature or DSA mastery is claimed.

### D2-EOD — Verify, evidence and ritual | 15 minutes

📚 Learn first: [Git recording changes](https://git-scm.com/book/en/v2/Git-Basics-Recording-Changes-to-the-Repository), refresh viewing/staging changes; stop before commit examples (2 minutes within this block).
↩ Return to build: inspect your own setup diff, record actual minutes and safe account evidence in [Day 2 evidence](part-17-day-02-evidence.md), and record the next failed gate; done when no secret is staged and all results are observed or pending; time box: remaining 13 minutes; if stuck: leave the item blocked rather than mark it Done.

Quiz: Why is readiness different from authentication? Why does changing an initialization environment variable not change an existing database password? Which minutes move when setup overruns? Interview question: explain host loopback ports, container service names and named volumes in 60 seconds. Evidence: account status, Compose review result, actual-time ledger and next action. Re-quiz on Day 4 or 5 within existing rituals; whiteboard within existing learning/ritual time. Learning is not complete until the learner supplies explain-back and verification evidence.

If behind: defer space polish and unfinished Compose authoring; never skip MFA, secret review or named blockers. Account spill displaces equal Day 6 feature minutes. Do not add hours.

## Day 3 — Sat Oct 3 — Section 8 runtime proof | 3 h

Corrected total: 30 Learn + 60 Implement + 30 Verify + 15 Storage + 30 uncommitted (former DSA) + 15 Ritual = 180 minutes. The former 210-minute allocation exceeded the cap. Stop at the cap and route unfinished work through the spill rule.

Day 3 operational work is now complete under the learner’s explicit setup-automation authorization. The blocks below are the planned ledger, not invented learner elapsed times. [Final evidence](part-17-day-03-evidence.md) records acceptance, native rootless host clients, preserved storage, remaining learning gaps and rollback artifacts. Do not repeat the transition merely to tick these planned blocks.

1. LEARN — 30 min: read S8-03/S8-04 links; explain health versus authentication versus storage retention.
2. IMPLEMENT — 60 min: finish learner-authored Compose corrections and run quiet config validation. Do not print resolved secrets.
3. VERIFY — 30 min: run S8-03 health, in-container PostgreSQL, host-port PostgreSQL, Redis `PONG`, wrong-password rejection, process-owner, and loopback-port checks.
4. STORAGE — 15 min: run S8-04 mount and cluster-ID baseline.
5. UNCOMMITTED — 30 min: former DSA slot; DSA deferred at learner request. Do not silently reallocate this time or claim DSA done.
6. RITUAL/EVIDENCE — 15 min: record sanitized results and stop/continue decision.

## Day 4 — Sun Oct 4 — Retention, docs, reproducibility | 3 h

1. LEARN — 20 min: read S8-05 and [README guidance](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-readmes); answer what makes a fresh clone reproducible.
2. VERIFY — 40 min: run S8-04 container recreation, prove PostgreSQL named-volume and cluster-ID retention, verify Redis disposable policy, then stop services without deleting volumes.
3. DOCUMENT — 45 min: write learner-owned sanitized Section 8 evidence, hardware evidence, troubleshooting row, and `SETUP.md` outline.
4. CI/DOCTOR SPEC — 35 min: write learner-owned doctor and CI skeleton specifications only; no application code.
5. UNCOMMITTED — 30 min: DSA remains deferred at learner request; no completion or automatic reallocation claimed.
6. RITUAL — 10 min: update status, actual minutes, spill.

## Day 5 — Mon Oct 5 — Review and S1 go/no-go | 1 h

1. REVIEW — 20 min: confirm Section 8 evidence has no blank pass fields; confirm Section 9 tools remain deferred.
2. RETRO — 15 min: record one success, one failure, one process change, actual setup time.
3. PLAN — 15 min: read [Part 18 Sprint 1](part-18-sprint1.md), select Day 6 checklist IDs, name equal feature time displaced by setup spill.
4. GO/NO-GO — 10 min: continue to S1 only if Section 8 passes; otherwise keep scope at setup and record blocker.

## Spill rules

- Section 8 spill displaces equal Day 6 feature time; it never adds hours.
- Atlassian/Jira may remain pending if email or MFA blocks; record next action.
- AWS remains deferred unless learner accepts signup/payment terms.
- Do not install Section 9 tools early: Ollama, models, MongoDB, Java, kind, kubectl, n8n, Chroma/Qdrant, Hugging Face, Colab/Kaggle, Playwright, or k6.
- Section 8 is complete only after S8-01 through S8-05 have dated, sanitized evidence.

Resource index: Day 2 official Atlassian account/MFA/space pages, Compose services, AWS Budgets, Git recording changes and linked-list problem opened successfully 2026-10-02. This verifies documentation access, not learner account status. Context7 unavailable. Prior sprint resources checked 2026-10-01: Part 4 Docker, Compose, PostgreSQL, Redis, Atlassian, README, and WSL resources verified; current UI/account eligibility remains learner-verified.

NEXT: Part 18 — Sprint 1, only after Section 8 completion gate and Day 5 go/no-go.
