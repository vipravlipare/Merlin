# Part 04 — Accounts completion record and checklist

Updated **2026-10-02**. Canonical checkout: `/home/vipra/Merlin`. This record replaces stale account status from the Windows planning copy. The learner creates and secures accounts; the mentor records reported evidence. No account, subscription, cloud resource or security setting was changed by the mentor.

## Account acceptance record

| Gate | Status and evidence |
|---|---|
| Atlassian access/email | Complete by learner report: email verified |
| Atlassian personal MFA | Complete by learner report: enabled and MFA sign-in works |
| Recovery storage | Learner reports recovery key stored in notes; contents and location deliberately not recorded. Keep those notes private and outside Git/Jira/shared planning |
| Jira site | `https://vipravlipare.atlassian.net` |
| Jira space key | `MER`; use the existing space, do not recreate it |
| Board | Scrum confirmed; team-managed setting not separately confirmed |
| Plan | Free confirmed; learner reports no paid products |
| Invitations | Not separately confirmed; no invitation action is required |
| GitHub account transport | Existing GitHub origin and prior SSH evidence; this does not establish web MFA |
| GitHub web MFA/visibility/recovery | Pending learner report; preserve existing visibility |
| AWS | Explicitly deferred under local-first $0 route; not configured |

The Atlassian access, MFA and Free-plan gates are complete by learner report. Full Part 4 account acceptance also includes GitHub web MFA and visibility, which remain unverified. Do not equate a deferred AWS branch with configured AWS MFA or budgets.

## AC-01 — Close GitHub status, without changing visibility

📚 Learn first: [GitHub MFA](https://docs.github.com/en/authentication/securing-your-account-with-two-factor-authentication-2fa/configuring-two-factor-authentication), read personal authenticator/recovery guidance; stop before alternative methods. Use existing account/evidence time; do not add a new block.
↩ Return: inspect GitHub Settings → Password and authentication and the existing repository's displayed visibility; done when MFA, current visibility and private recovery-storage status are recorded; time box: at most 5 minutes from remaining ritual/account time; if stuck: record pending rather than change the repository or buy a plan.

## AC-02 — Preserve confirmed Atlassian security

📚 Learn first: [Atlassian personal MFA](https://support.atlassian.com/atlassian-account/docs/manage-two-step-verification-for-your-atlassian-account/), refresh recovery storage only; stop before key regeneration.
↩ Return: retain the learner-reported account evidence above; done when recovery notes remain private and no secret enters shared evidence; time box: inside existing ritual; if stuck: record only storage status, never the recovery key. Do not repeat account signup or MFA enrollment.

## AC-03 — Preserve the existing MER Scrum space

📚 Learn first: [Team-managed spaces](https://support.atlassian.com/jira-software-cloud/docs/get-started-with-team-managed-projects/), read project/space settings; stop before customization.
↩ Return: inspect the existing MER settings for team-managed type if that fact is still unknown; done when type and solo/no-invitation status are recorded or explicitly pending; time box: remaining account time, at most 3 minutes; if stuck: retain the existing board and defer customization.

Keep the default workflow for Day 2. Written WIP limit: at most two active checklist items, one implementation and one learning/verification item. Full status customization, Jira import, automation and sprint population are later tasks; none is an extra Day 2 completion requirement. The actual key is MER, not the earlier proposed MERLIN.

## AC-04 — AWS deferral

📚 Learn first: [Part 1 ADR-05](part-01-waterfall-and-assumptions.md), read the local-first decision; stop before later ADRs.
↩ Return: retain `AWS deferred; local release; no AWS CLI, workload resources, access keys or signup required now`; done when no account/budget setup is claimed; time box: within ritual; if stuck: keep the local route. Future activation requires the learner's actual terms/payment decision and funded time.

## AC-05 — Evidence and hour boundary

📚 Learn first: [Day 2](part-17-sprint0.md#day-2--fri-oct-2--accounts-and-compose-correction--15-h), read the 90-minute ledger and closure instructions; stop before Day 3.
↩ Return: update [Day 2 evidence](part-17-day-02-evidence.md) with actual minutes and learning answers; done when only observed/reported facts are marked complete and missing proof stays pending; time box: the existing ritual, no extra minutes; if stuck: stop at 90 minutes and name unfinished gates.

One authoritative Day 2 allocation: Learn 15 + accounts 30 + Compose review 15 + DSA 15 + ritual 15 = **90 minutes**. The quoted older allocation totals 105 minutes and cannot fit 1.5 hours. Account subchecks share these blocks, rather than add to them. Full Section 8 execution is Day 3/4 work; spill displaces equal Day 6 feature time.

## Resource index

Atlassian MFA documentation re-opened successfully **2026-10-02**. GitHub MFA and team-managed docs were opened earlier on **2026-10-02** in this session; no account-specific settings were browsed by the mentor. Local ADR/schedule references verified against files. Context7 unavailable. No secrets are included here.
