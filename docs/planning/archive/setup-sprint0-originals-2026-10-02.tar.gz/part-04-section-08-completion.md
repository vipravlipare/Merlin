# Part 04 supplement — Section 8 completion specification

Status: **operational acceptance complete, 2026-10-02**. Latest explicit learner request “do it for me” authorizes assistant setup-only configuration changes, rootless client setup, controlled recreation and verification. No application feature code was created. [Final Day 3 evidence](part-17-day-03-evidence.md) records each observed pass and remaining learning/account limitations.

Current services are `postgres` and `redis`, pinned to the selected images, healthy, loopback-published, non-root, bounded by the specified limits/logging and connected to preserved named storage. Host and container positive/negative PostgreSQL authentication and Redis PING pass. Volume `merlin_postgres_data` and cluster ID `7691749973399031842` survived the controlled recreation. The private credential remains unchanged. AWS/optional tools remain deferred.

Use the specifications below as a reference for reproduction, not a list of unfinished work. Historical initial audits are in Section 8 evidence and are superseded by the final completion record. Learner explain-back/re-quiz/whiteboard and actual minutes remain unverified; an operational pass is not a claim of learner mastery.

Official Docker/PostgreSQL/Redis documentation and registry manifests checked **2026-10-02**; Context7 unavailable. Exact linux/amd64 image digests remain PostgreSQL `sha256:91eb910c44c7ed13f7f1a4ccadaa9ca72ef14cddc04cacb6e070e48eb44731a3` and Redis `sha256:7ef5b5cec96495a04ca7feff88a9492efeab8053fb284d24bdd73344c9245a48`.

## S8-01 — Confirm the boundary and choose image pins

📚 Learn first: [Compose application model](https://docs.docker.com/compose/intro/compose-application-model/), read services, networks and volumes; stop before examples (~3 minutes). [Inspect image manifests](https://docs.docker.com/reference/cli/docker/buildx/imagetools/inspect/), read description and default output; stop before formatting examples (~2 minutes). Explain back: How is an image different from a container, and why can a version tag change while a digest identifies fixed content?
↩ Return: record the repository path, Docker engine, Compose version, exact image tags, digest and target architecture in your Section 8 evidence notes; done when both image references are reproducible; time box: 10 minutes including reading; if stuck: inspect one registry manifest before changing any local service.

```bash
pwd
git rev-parse --show-toplevel
date -Iseconds
docker context show
docker version
docker compose version
docker info --format 'OS={{.OSType}} Architecture={{.Architecture}} MemoryBytes={{.MemTotal}}'
docker buildx imagetools inspect postgres:17.11-bookworm
docker buildx imagetools inspect redis:8.10.2-trixie
```

The repository must be the intended Linux Git checkout. The engine must be Linux. Read the `Digest` and `linux/amd64` manifest information; do not fabricate a digest or copy one from this guide. The proposed exact tags are `postgres:17.11-bookworm` and `redis:8.10.2-trixie`. In your own Compose file, pin each image using its official repository, exact tag and observed `sha256` digest. Record whether you used the multi-platform index digest or the `linux/amd64` manifest digest. A registry failure leaves pin verification pending; do not silently substitute `latest`. [Postgres official image](https://hub.docker.com/_/postgres), [Redis official image](https://hub.docker.com/_/redis/)

## S8-02 — Author the minimal Compose configuration

📚 Learn first: [Compose services reference](https://docs.docker.com/reference/compose-file/services/), read `healthcheck`, `mem_limit`, `ports` and `logging`; stop after those sections (~7 minutes). [Postgres official image](https://hub.docker.com/_/postgres), read Environment Variables, PGDATA and Arbitrary `--user` Notes (~4 minutes). [Redis official image](https://hub.docker.com/_/redis/), read Security and Process User and Privileges (~2 minutes). The examples contain finished configuration: write your own, then explain every field.
↩ Return: author your configuration from the table, then validate it without printing resolved secrets; done when validation exits zero and the field review passes; time box: 35 minutes including reading; if stuck: after 25 focused minutes, use hint 1 below and preserve your attempt.

| Field or decision | Required behavior in your learner-authored configuration |
|---|---|
| Project and service names | Keep one stable project identity for this checkout. Use `postgres` and `redis` as service names so the commands below match. Do not reuse another project's volumes. |
| Images | Use the exact observed pins from S8-01. No application `build` section is needed. |
| Host ports | Publish PostgreSQL TCP 5432 and Redis TCP 6379 **only on host address `127.0.0.1`**. Record another host port if occupied. Never omit the host IP or substitute `0.0.0.0` or `::`. |
| Network | One project-scoped bridge network shared by these two services. No host network, external network, Docker socket mount or privileged container. |
| PostgreSQL storage | Declare one named volume mounted at `/var/lib/postgresql/data` for this 17.x official image. Do not use PostgreSQL 18's different mount convention. |
| PostgreSQL environment | Declare `POSTGRES_USER`, `POSTGRES_DB` and `POSTGRES_PASSWORD` as required inputs. Store values only in your private, ignored local environment file. Require a nonempty password; never enable blanket external-host authentication `trust`. The image’s existing local socket/container-loopback trust rules must not be mistaken for a password test; host-published connections must reject the wrong password. These initialization inputs do not reset an already initialized volume. The bootstrap database user is privileged; an application role is later work. |
| Secret boundary | No literal password in Compose, tracked files or example files. An example specification contains names and descriptions only. Do not print the full resolved Compose configuration or an unfiltered container inspection. A local environment file is not encrypted secret storage. |
| Redis persistence | For this initial connectivity-only setup, explicitly disable snapshots and append-only persistence. Use a named volume for its `/data` directory to avoid unmanaged anonymous-volume accumulation; this does **not** make in-memory keys durable. Record Redis as disposable. A durable queue requires a later persistence decision and test. |
| Redis authentication | Initial scope permits only trusted-local, synthetic use with loopback publication. State explicitly that authentication is not configured. The official image does not gain authentication merely from a `REDIS_PASSWORD` environment name. Do not store sensitive data or reuse this policy for deployment. |
| Health checks | PostgreSQL: run `pg_isready` inside the service using its configured username and database. Redis: run `redis-cli` PING inside the service. Target interval 10 seconds, timeout 5 seconds, five retries and a 30-second start period. A PostgreSQL readiness result alone is not a password test. |
| Startup dependencies | PostgreSQL and Redis do not depend on one another. Do not invent `depends_on` between them. A future API must wait for their healthy state. |
| Process user | Preserve each official entrypoint's initialization and privilege-drop behavior. Verify the running database/server process is non-root. Do not blindly set a numeric `user` field: an empty volume may first need ownership initialization. |
| Limits | Starting project budget: PostgreSQL maximum 1 GiB RAM and 1 CPU; Redis maximum 256 MiB RAM and 0.5 CPU. Set Redis's own data-memory target to 128 MiB with an explicit no-eviction policy for this smoke setup. A container limit alone is not Redis's data limit. |
| Logs and lifecycle | Use bounded local logs; project target is three rotated files of at most 10 MiB per service. Permit a 30-second graceful stop. Prefer explicit learner startup during setup; document any automatic restart policy. |

For a shell health check written inside Compose, distinguish Compose's own variable interpolation from the container shell's expansion. A literal dollar sign is escaped as `$$` in Compose. Use that rule when the container, rather than the WSL host, must expand a health-check variable. [Compose interpolation](https://docs.docker.com/reference/compose-file/interpolation/)

These are project choices, not production sizing claims. The latest reported machine evidence is 16 GB host RAM, 7.6 GiB visible in Ubuntu and 47.7 GiB free on C:. The 1.25 GiB combined service ceiling leaves room for tools, but WSL memory visibility is not proof of total host headroom. Docker's virtual disk shares physical storage: budget no more than 5 GiB for this empty core stack and investigate growth rather than pruning data. Pause new downloads below a project threshold of 20 GiB free on C:. [Docker resource limits](https://docs.docker.com/engine/containers/resource_constraints/)

Loopback publication limits host exposure; it does not isolate the databases from other processes owned by a local user or from containers on the same network. Redis's official image disables protected mode by default. Treat this as a recorded local development limitation, not a production security pass. [Docker port publication](https://docs.docker.com/engine/network/port-publishing/), [Redis security](https://redis.io/docs/latest/operate/oss_and_stack/management/security/)

```bash
docker compose config --quiet
printf 'validation exit=%s\n' "$?"
docker compose config --services
docker compose config --images
git check-ignore .env
git ls-files --error-unmatch .env
```

Expected: validation exit 0; exactly the two intended services; both images pinned; `.env` is ignored and the final command reports that `.env` is **not tracked**. Run the exit-status line immediately after validation. If your private file has another name, substitute that name in the two Git checks. Stop if it is tracked. Do not display its contents. [Compose validation](https://docs.docker.com/reference/cli/docker/compose/config/)

Hint ladder: **1:** distinguish the host endpoint, container endpoint and persistent directory. **2:** validate PostgreSQL first, then add Redis using the same review. **3:** paste your redacted attempt before requesting a small configuration hint; the mentor does not author the finished configuration.

## S8-03 — Start and verify the learner's services

📚 Learn first: [Compose startup](https://docs.docker.com/reference/cli/docker/compose/up/), read `--wait` and `--wait-timeout` (~2 minutes); [pg_isready](https://www.postgresql.org/docs/17/app-pg-isready.html), read exit status (~2 minutes); [psql](https://www.postgresql.org/docs/17/app-psql.html), read connection options and `--list` (~3 minutes). Explain back: Why do service health, password authentication and host-port access need separate evidence?
↩ Return: start only the two reviewed services yourself and capture the checks below; done when health, local SQL access, Redis response and loopback bindings pass; time box: 25 minutes including reading; if stuck: inspect the last 50 log lines locally and preserve the first decisive error with secrets removed.

For the initial db/cache → postgres/redis rename, first follow worksheet W4 after S8-02 review: verify project/storage baseline and remove the old project service containers without removing volumes. Otherwise retained fixed container names or occupied ports can block startup.

The next command creates containers, downloads missing pinned images and uses existing storage (or initializes it only if absent). It is a **learner action**, not a check the mentor has already executed. Run it only after S8-02 passes.

```bash
docker compose up --wait --wait-timeout 120 postgres redis
docker compose ps
docker compose images
docker compose port postgres 5432
docker compose port redis 6379
docker compose exec -T postgres sh -c 'pg_isready -h 127.0.0.1 -U "$POSTGRES_USER" -d "$POSTGRES_DB"'
docker compose exec -T postgres sh -c 'psql -X --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" --list'
docker compose exec -T redis redis-cli PING
docker compose top
```

Expected: both services healthy; published endpoints `127.0.0.1:5432` and `127.0.0.1:6379` unless you deliberately changed host ports; PostgreSQL accepts connections and lists the configured database; Redis returns `PONG`; long-running database/server processes have non-root owners. If any service is missing or unhealthy, stop here. [Compose status](https://docs.docker.com/reference/cli/docker/compose/ps/), [Compose port](https://docs.docker.com/reference/cli/docker/compose/port/), [Compose top](https://docs.docker.com/reference/cli/docker/compose/top/), [Redis PING](https://redis.io/docs/latest/commands/ping/)

In the PostgreSQL commands, outer single quotes keep the WSL shell from expanding variables. The container shell expands its own `POSTGRES_USER` and `POSTGRES_DB`; inner double quotes preserve each value as one argument. These commands do not print a password. The in-container `psql` command uses the local socket, so it does **not** prove host-port authentication. After the corrected service is running, additionally check password authentication through its service DNS name, without printing the configured password:

```bash
docker compose exec -T postgres sh -c 'PGPASSWORD="$POSTGRES_PASSWORD" psql -X -h postgres -U "$POSTGRES_USER" -d "$POSTGRES_DB" --no-password --list'
docker compose exec -T postgres sh -c 'PGPASSWORD=merlin-deliberately-wrong-test psql -X -h postgres -U "$POSTGRES_USER" -d "$POSTGRES_DB" --no-password --list'
```

The first must succeed and the second must fail with password authentication rejected. The deliberately wrong test string is synthetic, not a credential. These checks supplement, rather than replace, the required WSL host checks. [Compose exec](https://docs.docker.com/reference/cli/docker/compose/exec/)

For the separate host-port check, use `psql` and `redis-cli` installed in Ubuntu. Check their availability first:

```bash
command -v psql
command -v redis-cli
apt-cache policy postgresql-client redis-tools
```

If either client is absent, record that core prerequisite as pending. The package-policy output identifies the candidates available from your configured Ubuntu repositories. Use the official `postgresql-client` and `redis-tools` packages as a separate learner setup action; do not install another database server. Review [Ubuntu package management](https://ubuntu.com/server/docs/how-to/software/package-management/), the APT installation section, before that action. Do not count in-container commands as a replacement for the host-port check. With both clients available:

```bash
read -r -p 'Configured PostgreSQL username: ' setup_pg_user
read -r -p 'Configured PostgreSQL database: ' setup_pg_database
psql -X --host=127.0.0.1 --port=5432 --username="$setup_pg_user" --dbname="$setup_pg_database" --password --list
redis-cli -h 127.0.0.1 -p 6379 PING
```

Enter the database password only at the `psql` password prompt. The prompt hides input. Substitute your recorded host ports if different. Repeat the PostgreSQL command once with an intentionally wrong password: it must reject authentication. Record only the error category, not credentials. A failed WSL host-port check remains a blocker even if Docker Desktop reports healthy containers; troubleshoot that boundary without broadening the bind address.

Inspect diagnostics locally. Logs are not guaranteed to be secret-free; redact before copying into evidence or chat:

```bash
docker compose logs --no-color --tail=50 postgres redis
docker stats --no-stream
docker system df
```

## S8-04 — Prove storage and understand stopping

📚 Learn first: [Docker volumes](https://docs.docker.com/engine/storage/volumes/), read lifecycle and named versus anonymous volumes (~3 minutes); [Compose down](https://docs.docker.com/reference/cli/docker/compose/down/), read default behavior and volume option (~2 minutes); [pg_controldata](https://www.postgresql.org/docs/17/app-pgcontroldata.html), read description (~1 minute). Explain back: Why is deleting a container different from deleting its database volume?
↩ Return: record PostgreSQL's initialized cluster identifier and volume before and after a controlled container recreation; done when the same volume and cluster return and both services are healthy; time box: 20 minutes including reading; if stuck: retain volumes and investigate the mount instead of resetting data.

Only continue if both service IDs below are nonempty. These filtered inspections avoid printing environment values:

```bash
setup_pg_id="$(docker compose ps -q postgres)"
setup_redis_id="$(docker compose ps -q redis)"
printf 'postgres=%s\nredis=%s\n' "$setup_pg_id" "$setup_redis_id"
docker inspect --format '{{json .Mounts}}' "$setup_pg_id"
docker inspect --format '{{json .Mounts}}' "$setup_redis_id"
docker inspect --format 'Image={{.Config.Image}} Memory={{.HostConfig.Memory}} NanoCpus={{.HostConfig.NanoCpus}}' "$setup_pg_id" "$setup_redis_id"
docker compose exec -T --user postgres postgres sh -c 'pg_controldata "$PGDATA"'
docker compose exec -T redis redis-cli CONFIG GET save appendonly maxmemory maxmemory-policy
```

Record the PostgreSQL `Database system identifier` and named volume. Redis should show snapshots disabled, append-only disabled, and the chosen memory/eviction policy. The volume records confirm where files would go; they do not prove Redis key durability. Do not write feature tables or seed application data for this setup check. [Redis persistence](https://redis.io/docs/latest/operate/oss_and_stack/management/persistence/)

To test container recreation, the learner runs these operations in sequence. They interrupt this local stack but preserve named volumes:

```bash
docker compose down
docker compose up --wait --wait-timeout 120 postgres redis
docker compose ps
docker compose exec -T --user postgres postgres sh -c 'pg_controldata "$PGDATA"'
docker compose exec -T postgres sh -c 'psql -X --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" --list'
docker compose exec -T redis redis-cli PING
```

Re-run the filtered mount checks with **new** container IDs. The PostgreSQL system identifier, database list and named volume must match the baseline. This proves retention of the initialized cluster across recreation; application-data restore testing belongs to a later slice. Redis is deliberately disposable here.

For a normal pause, use `docker compose stop --timeout 30`; containers and volumes remain. For removing this project's containers and network while retaining data, use `docker compose down`. Never append the volume-deletion option for routine stopping. Volume deletion and Docker pruning are outside this completion procedure. [Compose stop](https://docs.docker.com/reference/cli/docker/compose/stop/)

## S8-05 — Record evidence and apply the completion gate

📚 Learn first: [Compose configuration validation](https://docs.docker.com/reference/cli/docker/compose/config/), refresh quiet validation (~1 minute); [Docker port publication](https://docs.docker.com/engine/network/port-publishing/), refresh loopback behavior (~1 minute). Explain back: Which result proves readiness, which proves authentication, and which proves storage retention?
↩ Return: write sanitized observations in `docs/planning/part-04-section-08-evidence.md`; done when every row below has dated evidence or a named blocker; time box: 10 minutes including reading; if stuck: mark pending rather than copying an expected result as an observation.

| Case | Pass criterion | Evidence to record |
|---|---|---|
| Configuration | Quiet validation exits zero; exactly two services; digest pins present | Timestamp, repository commit, versions, image references and validation exit |
| Health | Both services healthy within the 120-second startup allowance | `compose ps`, elapsed time, failure details if any |
| PostgreSQL | In-container list works; host-port list works with correct password | Database name, connection boundary, result; no password |
| Authentication negative | Wrong PostgreSQL password is rejected | Redacted failure category |
| Redis | Host and container PING return `PONG` | Both results; explicit unauthenticated trusted-local limitation |
| Exposure negative | Every published database port has only `127.0.0.1` as host bind; no host networking | Port and reviewed configuration evidence; do not claim a LAN penetration test occurred |
| Process and resource limits | Database/server processes are non-root; inspected memory/CPU limits match design | Process owners, limits, a resource snapshot and Windows physical free-disk observation |
| Storage | Same PostgreSQL named volume, system identifier and database list after recreation | Before/after values; Redis disposable policy |
| Secrets | Private local environment file ignored and untracked; shared logs manually redacted | Git check results and redaction statement |
| Lifecycle and learning | Learner explains stop versus removal versus volume deletion; no pending failures hidden | Explain-back answers, actual minutes and next check |

Blank fields mean pending. A blocked client installation or host-port test means Section 8 is not complete. This supplement cannot establish account, SSH, editor or dependency status; those are separate Sections 1–7 gates. No cache, queue, application schema, GPU workload or production deployment is claimed.

## Section 9 — Just-in-time install guard

Part 04 Section 9 is a scheduling gate, not an installation task. Keep these tools out of the current lockfiles and Docker stack:

| Tool | First-use gate | Action now |
|---|---|---|
| Ollama and models | Day 8/16 hardware and model benchmark | Do not install |
| MongoDB | Conditional Day 31 funded swap | Do not install |
| Java/Maven/Spring Boot | Conditional Day 31 funded swap | Do not install |
| kind/kubectl | Conditional Day 32 after core completion | Do not install |
| n8n | Conditional Day 28 after scratch workflow | Do not install |
| Chroma/Qdrant | Conditional measured comparison | Do not install |
| Hugging Face/Colab/Kaggle | Conditional Day 30 license/quota gate | Do not create accounts yet |
| AWS CLI beyond account alarm | Conditional Day 25/32 | Keep AWS deferred |
| Playwright browsers and k6 | Conditional Day 34 swap | Do not install |

📚 Learn first: [Ollama API introduction](https://docs.ollama.com/api/introduction), read only the API base URL; [Docker WSL 2 backend](https://docs.docker.com/desktop/features/wsl/), read resource settings; stop before model downloads and Kubernetes (~5 minutes).
↩ Return: finish S8-02 through S8-05 first, then install only the tool named by its scheduled Jira task; done when no optional tool enters the environment early; time box: 5 minutes; if stuck: record the deferred tool and continue Section 8.

Section 9 is complete for now when the learner has recorded the deferred list, has not installed optional tools, and understands that any later addition is a swap within the hour budget.

## Capacity and stop condition

The five boxes total **100 minutes**, including reading and evidence. They fit inside the revised Part 17 Day 3/4 setup and verification blocks; do not charge their reading/evidence again. Day 2 stays 90 minutes (15 Learn, 30 accounts, 15 Compose review, 15 DSA, 15 ritual). Day 3 stays 180 (30 Learn, 60 authoring, 30 runtime, 15 storage baseline, 30 DSA, 15 ritual). Day 4 stays 180 as written in Part 17. S8-01 is observed, but learner explain-back and actual execution time are still required.

The original Part 1 minimal Compose allocation was 30 minutes, so completing the 100-minute procedure requires a 70-minute scope swap somewhere in the ledger. The revised Day 3/4 plan routes setup into time originally intended for repository/hooks/CI/fresh-clone work; it does not complete those displaced tasks. Record their actual remaining minutes as spill and subtract them from Day 6 feature capacity minute-for-minute. If the original 70-minute deficit is still outstanding at that point, Day 6 is 70 setup + 179 other net work + 30 DSA + 45 ritual + 36 reserve = 360 minutes. Do not count the same deficit twice or assume actual elapsed minutes equal estimates.
📚 Learn first: [Part 1, exact spill routing](part-01-waterfall-and-assumptions.md), read §7.2; stop before the next section (~1 minute within evidence time). Explain back: Which feature minutes move if setup takes longer?
↩ Return: record actual time and the displaced work in the evidence note; done when the daily budget still reconciles; time box: within S8-05; if stuck: stop and name the unfinished gate. Re-quiz the three explain-back questions in S8-01, S8-03 and S8-04 two to three days after execution; count it within the existing ritual allowance. Whiteboard the host, ports, containers and volumes in 10 minutes within the existing learning/ritual budget before claiming mastery.

## Resource index

All following links were opened successfully on **2026-10-01**. Verification covers documentation access and documented behavior, not execution on this machine.

- [Compose application model](https://docs.docker.com/compose/intro/compose-application-model/); [services](https://docs.docker.com/reference/compose-file/services/); [manifest inspection](https://docs.docker.com/reference/cli/docker/buildx/imagetools/inspect/).
- [Compose interpolation](https://docs.docker.com/reference/compose-file/interpolation/); [Ubuntu package management](https://ubuntu.com/server/docs/how-to/software/package-management/).
- [Postgres official image](https://hub.docker.com/_/postgres); [Redis official image](https://hub.docker.com/_/redis/).
- [Configuration](https://docs.docker.com/reference/cli/docker/compose/config/); [startup](https://docs.docker.com/reference/cli/docker/compose/up/); [status](https://docs.docker.com/reference/cli/docker/compose/ps/); [exec](https://docs.docker.com/reference/cli/docker/compose/exec/); [port](https://docs.docker.com/reference/cli/docker/compose/port/); [processes](https://docs.docker.com/reference/cli/docker/compose/top/).
- [Resource limits](https://docs.docker.com/engine/containers/resource_constraints/); [port publication](https://docs.docker.com/engine/network/port-publishing/); [volumes](https://docs.docker.com/engine/storage/volumes/); [stop](https://docs.docker.com/reference/cli/docker/compose/stop/); [down](https://docs.docker.com/reference/cli/docker/compose/down/).
- [PostgreSQL readiness](https://www.postgresql.org/docs/17/app-pg-isready.html); [psql](https://www.postgresql.org/docs/17/app-psql.html); [cluster metadata](https://www.postgresql.org/docs/17/app-pgcontroldata.html).
- [Redis PING](https://redis.io/docs/latest/commands/ping/); [persistence](https://redis.io/docs/latest/operate/oss_and_stack/management/persistence/); [security](https://redis.io/docs/latest/operate/oss_and_stack/management/security/).

October 2 additions: PostgreSQL HBA rules and core Docker/Postgres/Redis pages opened successfully 2026-10-02; selected image manifests inspected directly from the registry. Actual corrected runtime gates remain pending.
